package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;

import org.apache.tomcat.util.buf.HexUtils;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
@RestController
class ServerController{
	//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
    @GetMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException{
    	String data = "Hello!This is Christina Jimenez's CheckSum!";
    	MessageDigest msgDigest = MessageDigest.getInstance("SHA-256");
    	byte[] hashBytes = msgDigest.digest(data.getBytes(StandardCharsets.UTF_8));
    	String checksum = HexUtils.toHexString(hashBytes);
        return "<p>data:"+data + "</p>" +
    			"<p>checksum: " + checksum +"</p>";
    }
}
